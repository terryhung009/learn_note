let title = '提示訊息：'  // string 字串
let title1 = '錯誤'
let title2 = '成功'

let alert1 = title + title1
let alert2 = title + title2

console.log(alert1)
console.log(alert2)

let score = 100 // number 數字
// + - * / %
// console.log(score % 3)

// let isFake = true // true false boolean 布林
// console.log(isFake)

// let bag = undefined 
// console.log(bag)

// let bag2 = null 
// console.log(bag2)

// var let const

const a1 = "aaaa"
console.log(a1)
// 修改a1的內容
// a1 = "bbb"
console.log(a1)


