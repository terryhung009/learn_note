# 【前端速成】JS 快速入門｜Tiktok工程師帶你入門前端｜布魯斯前端

## 說明
- 這是備忘錄APP的原始碼。

## Youtube影片連結
- https://youtu.be/1pYtVwIAvhY