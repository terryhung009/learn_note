package main

import "fmt"

func main() {
	km := 2
	if km > 2 {
		fmt.Println("搭車吧")
	} else {
		fmt.Println("用走的好了")
	}
}
