package main

import (
	f "fmt"
)

func main() {
	f.Println("Hello, Go 技術者們!")
}
