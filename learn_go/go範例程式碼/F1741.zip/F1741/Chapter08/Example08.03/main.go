package main

import (
	"fmt"

	"golang.org/x/example/stringutil"
	// "github.com/ozgio/strutil"
)

func main() {
	fmt.Println(stringutil.Reverse("!selpmaxe oG ,olleH"))
	// fmt.Println(strutil.Reverse("!selpmaxe oG ,olleH"))
}
