package main

import "fmt"

func
main(){
  firstVar := 1
       secondVar :=    2

  fmt.Println(firstVar)
                  fmt.Println(secondVar)
	fmt.    Println("Hello Packt")
                    }

/*
package main

    import "fmt"

func
main(){
  firstVar := 1
       secondVar :=    2

  fmt.Println(firstVar)
                  fmt.Println(secondVar)
	fmt.    Println("Hello Packt")
                    }
*/
