package main

import "fmt"

func main() {
	fmt.Println("Hello Windows!")
	fmt.Println(greetings())
}
