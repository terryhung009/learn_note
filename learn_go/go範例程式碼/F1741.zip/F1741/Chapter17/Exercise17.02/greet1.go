// +build windows

package main

func greetings() string {
	return "Greetings from Windows!"
}
