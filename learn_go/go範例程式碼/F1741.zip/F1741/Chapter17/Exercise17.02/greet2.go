// +build linux

package main

func greetings() string {
	return "Greetings from Linux!"
}
