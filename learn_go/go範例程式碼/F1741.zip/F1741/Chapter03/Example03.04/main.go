package main

import "fmt"

func main() {
	var a int8 = 128
	fmt.Println(a)
}
