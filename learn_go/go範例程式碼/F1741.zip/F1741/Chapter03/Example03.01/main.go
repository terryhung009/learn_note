package main

import "fmt"

func main() {
	fmt.Println(10 > 5)
	fmt.Println(10 == 5)
}
