package main

import "fmt"

func main() {
	offset := 5
	fmt.Println(offset)
	offset = 10
	fmt.Println(offset)
}
