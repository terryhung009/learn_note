package main

import "fmt"

func main() {
	firstName := "Bob"
	familyName := "Smith"
	age := 34
	peanutAllergy := false

	fmt.Println(firstName)
	fmt.Println(familyName)
	fmt.Println(age)
	fmt.Println(peanutAllergy)
}
