package main

import "fmt"

func main() {
	givenName := "John"
	familyName := "Smith"
	fullName := givenName + " " + familyName
	fmt.Println("Hello,", fullName)
}
