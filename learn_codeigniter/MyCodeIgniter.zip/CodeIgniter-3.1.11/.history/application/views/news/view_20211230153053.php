<?php
echo '<h2>'.$news_item['title'].'</h2>';
echo $news_item['text'];
<br>
echo site_url('news/local/123');