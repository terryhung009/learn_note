<html>
<head>
	<title><?php echo $title ?> - CodeIgniter 示範</title>
</head>
<body>
	<h1>CodeIgniter 示範</h1>