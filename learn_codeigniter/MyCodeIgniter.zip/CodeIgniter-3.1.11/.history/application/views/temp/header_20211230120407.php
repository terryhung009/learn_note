<html>
<head>
	<title><?php echo $title ?> - CodeIgniter 2 教學</title>
</head>
<body>
	<h1>CodeIgniter 2 教學</h1>