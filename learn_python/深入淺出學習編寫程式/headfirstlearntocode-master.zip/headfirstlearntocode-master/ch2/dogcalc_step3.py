dog_name = input("What is your dog's name? ")
dog_age = input("What is your dog's age? ")
human_age = int(dog_age) * 7
print('Your dog', 
       dog_name,
       'is',
       human_age,
       'years old in human years')
