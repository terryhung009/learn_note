dog_name = input("What is your dog's name? ")
dog_age = input("What is your dog's age? ")
