dog_name = input("What is your dog's name? ")
dog_age = int(input("What is your dog's age? "))
human_age = int(dog_age) * 7
print(human_age)
