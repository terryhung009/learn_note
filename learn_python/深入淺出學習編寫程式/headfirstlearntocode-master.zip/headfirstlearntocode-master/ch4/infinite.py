counter = 10

while counter > 0:
    print('Counter is', counter)
    counter = counter + 1
