import random 

random_choice = random.randint(0,2)
print('The computer chooses', random_choice)
