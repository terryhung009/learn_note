from tkinter import *

root = Tk()
root.title('The Game of Life')

start_button = Button(root, text='Start', width=12)

start_button.pack()

mainloop()
