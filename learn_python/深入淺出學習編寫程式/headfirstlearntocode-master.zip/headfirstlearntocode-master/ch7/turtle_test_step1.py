import turtle

slowpoke = turtle.Turtle()
slowpoke.shape('turtle')


slowpoke.forward(100)
slowpoke.right(90)
slowpoke.forward(100)
slowpoke.right(90)
slowpoke.forward(100)
slowpoke.right(90)
slowpoke.forward(100)
slowpoke.right(90)

turtle.mainloop()
