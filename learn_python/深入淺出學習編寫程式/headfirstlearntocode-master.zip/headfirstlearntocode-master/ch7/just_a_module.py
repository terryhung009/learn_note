if __name__ == '__main__':
    print("Look, I'm the main program y'all.")
else:
    print("Oh, I'm just a module.")
