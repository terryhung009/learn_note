import turtle

slowpoke = turtle.Turtle()
slowpoke.shape('turtle')

for i in range(5):
    slowpoke.forward(100)
    slowpoke.right(144)

turtle.mainloop()
