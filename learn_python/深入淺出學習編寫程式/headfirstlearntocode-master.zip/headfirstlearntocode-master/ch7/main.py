import just_a_module
    
print('Greetings from main.py')
