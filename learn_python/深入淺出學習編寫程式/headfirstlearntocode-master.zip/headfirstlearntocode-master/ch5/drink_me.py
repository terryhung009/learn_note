def drink_me(param):
    msg = 'Drinking ' + param + ' glass'
    print(msg)
    param = 'empty'

glass = 'full'
drink_me(glass)
print('The glass is', glass)
