package com.thishkt.pharmacydemo

const val PHARMACIES_DATA_URL="https://raw.githubusercontent.com/thishkt/pharmacies/master/data/info.json"